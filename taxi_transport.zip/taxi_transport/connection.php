<?php
$con= new mySQLi("localhost","root","","taxi_trasport") or die("$con->error");
?>
<?php
session_start();
include ("connection.php");
if(isset($_POST["btn_S"])){
        $user=$_POST["useName"];
        $pass=$_POST["pass"];
        $role=$_POST["role"];
    
    
        $FirstN=$_POST["FirstName"];
        $LastN=$_POST["LastName"];
        $adres=$_POST["addres"];
        $phon=$_POST["phone"];
        $email=$_POST["email"];
        $nation=$_POST["nation"];
        
        $pNo=$_POST["Plateno"];
        $liceC=$_POST["licenc"];
        $model=$_POST["Carmodel"];
        
         $carL=$_POST["Carlicense"];
        $carC=$_POST["CarColor"];
        $tinNo=$_POST["tinNumber"];
        
        $station=$_POST["Stationname"];
        $street=$_POST["Street"];

               
        header('location:viewdriver.php');
}
?>
<?php 
session_start();
include ("connection.php");
$id=$_GET['userN'];
$sql=$con->query("Delete from logins where userName='$id'");
$row=mysqli_num_rows($sql);
if($row<1){
    $_SESSION['deleted'] = "Record successfully deleted";
    header("Location:viewdriver.php");
    exit();
}
else{
    $_SESSION['error'] = "Operation fails ";
    header("location:viewdriver.php");
    exit();
}


?>
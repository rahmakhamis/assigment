<?php
session_start();
include ("connection.php");
if(isset($_POST["btn_S"])){
        $user=$_POST["useName"];
        $pass=$_POST["pass"];
        $role=$_POST["role"];
    
    
        $FirstN=$_POST["FirstName"];
        $LastN=$_POST["LastName"];
        $adres=$_POST["addres"];
        $phon=$_POST["phone"];
        $email=$_POST["email"];
        $nation=$_POST["nation"];
        

        $check=$con->query("SELECT * from logins WHERE userName ='$user'") or die("$con->error");		 
       $rows=mysqli_num_rows($check);
       if($rows==1){
           $_SESSION["fail"]="The user name already exist";
		header("location:customerReg.php");
           
       }else{
           
                       $logintr=$con->query("INSERT INTO logins VALUES('$user','$pass','$role','$FirstN','$LastN','$adres','$phon','$email','$nation')");
                       
                       $driverr=$con->query("INSERT INTO customer VALUES(NULL,'$user')")or die("$con->error");
                       
                       header("location:index.php");
               
       }
}
?>
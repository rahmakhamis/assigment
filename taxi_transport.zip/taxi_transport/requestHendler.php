<?php
session_start();
include ("connection.php");
if(isset($_POST["btn_S"])){
    
    
        $driver=$_POST["driver"];
        $area=$_POST["areas"];
        $date= date('20'.'y/m/d');
        $userN=$_SESSION["users"];
        
        $sql4=$con->query("SELECT * FROM customer,logins where logins.userName='$userN' and logins.userName=customer.userName")or die($db_con->error);
	
        while($row=mysqli_fetch_array($sql4)){
                $custID=$row['custID'];
        }
        $driver1=$con->query("INSERT INTO request VALUES(NULL,'$date','$area','$driver','$custID')")or die("$con->error");
        $numRow=mysqli_num_rows($driver1);
        if($numRow < 1){
            $driver2=$con->query("update driver set status=1,custID='$custID' where driverID='$driver'");
                header('location:viewRequest.php');
        }   
}
?>
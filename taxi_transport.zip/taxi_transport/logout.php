<?php
	session_start();
	unset($_sesion["user"]);
	unset($_session["role"]);
	session_destroy();
	header("location:index.php");

?>
<?php
session_start();
include ("connection.php");
if(isset($_POST["user_name"])){
        $user=$_POST["user_name"];
        $pass=$_POST["pass_word"];
        $FirstN=$_POST["f_name"];
        $LastN=$_POST["l_name"];
       
        

        $check=$con->query("SELECT * from logins WHERE userName ='$user'") or die("$con->error");		 
       $rows=mysqli_num_rows($check);
       if($rows==1){
           echo "already exixt!";
       }else{
           
                       $logintr=$con->query("INSERT INTO logins VALUES('$user','$pass','Customer','$FirstN','$LastN','','','','')");
                       
                       $driverr=$con->query("INSERT INTO customer VALUES(NULL,'$user')")or die("$con->error");
                       
                      echo "Successfull Registration";
               
       }
}
?>
<?php
	require_once("connection.php");
	if(isset($_POST['username'])){
		$user=$con->real_escape_string($_POST['username']);
		$pass=$con->real_escape_string($_POST['pass']);
		

	$sql=$con->query("SELECT * FROM logins WHERE userName='$user' AND pass='$pass'") or die (mysqli_error());
	$num=mysqli_num_rows($sql);
	if($num==1){
		$query=mysqli_fetch_array($sql);
				/*$_SESSION["users"]=$query[userName];
				$_SESSION["role"]=$query[role];
                $_SESSION["f_Name"]=$query[f_Name];
                $_SESSION["l_Name"]=$query[l_Name];
                $_SESSION["address"]=$query[address];
                $_SESSION["phone"]=$query[phone];
                $_SESSION["email"]=$query[email];
                $_SESSION["national"]=$query[national];*/
		echo "valid";
	}else{
		echo "fail try again!";

	}
	}



	//$con->close();

?>
<?php
$con= new mySQLi("localhost","root","suzabest","taxi_trasport") or die("$con->error");
?>
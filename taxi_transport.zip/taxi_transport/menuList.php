<ul>
    <?php
	if($_SESSION["role"]=="Admin"){
	?>
    <li style="margin-top: 20px">
        <a href="home.php">Home</a>
    </li>
    <li style="margin-top: 20px">
        <a href="viewdriver.php">Register Drivers</a>
    </li>
    <li style="margin-top: 20px">
        <a href="viewCustomer.php">View Customer</a>
    </li>
    <?php
	}elseif($_SESSION["role"]=="Driver"){		
	?>
    <li style="margin-top: 20px">
        <a href="home.php">Home</a>
    </li>
    <li style="margin-top: 20px">
        <a href="replayView.php">View Request</a>
    </li>
    <?php
	}else{
	?>
     <li style="margin-top: 20px">
         <a href="home.php">Home</a>
    </li>
    <li style="margin-top: 20px">
        <a href="viewRequest.php">Send Request</a>
    </li>
    <li style="margin-top: 20px">
        <a href="customerViewReplay.php">View Reply</a>
    </li>
    <?php
	}
	?>
</ul>
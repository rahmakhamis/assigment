<?php 
session_start();
include ("connection.php");
$ids=$_GET['idRequest'];
$userN=$_SESSION["users"];
$date= date('20'.'y/m/d');


$sql=$con->query("SELECT * FROM taxi_transport.driver where driver.userName='$userN';")or die("$con->error");

while($row=mysqli_fetch_array($sql)){
        $driverID=$row['driverID'];
}
$accept=$con->query("INSERT INTO reply VALUES(NULL,'$ids','$date','$driverID',-1)")or die("$con->error");
    header("Location:viewReplayDriver.php");



?>
<?php 
include ("connection.php");
session_start();
if(isset($_POST["log_btn"])){
	$username=$_POST["user"];
	$password=$_POST["pass"];
	
    $sql=$con->query("SELECT * FROM logins WHERE userName='$username' AND pass='$password'") or die (mysqli_error());
	$num=mysqli_num_rows($sql);
	if($num==1){
		$query=mysqli_fetch_array($sql);
		$_SESSION["users"]=$query[userName];
		$_SESSION["role"]=$query[role];
                $_SESSION["f_Name"]=$query[f_Name];
                $_SESSION["l_Name"]=$query[l_Name];
                $_SESSION["address"]=$query[address];
                $_SESSION["phone"]=$query[phone];
                $_SESSION["email"]=$query[email];
                $_SESSION["national"]=$query[national];
		header("location:home.php");
	}else{
		$_SESSION['invalid']="Invalid Username or Password";
		header("location:index.php");
	}
	}
	
?>
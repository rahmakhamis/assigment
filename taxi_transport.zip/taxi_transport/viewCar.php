<?php
include ("connection.php");
session_start();
if(!isset($_SESSION['users'])){
	header("location:index.php");
}
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>TAXI DRIVER</title>
        
        <link href="bootstrap/css/bootstrap.css" rel="stylesheet" type="text/css"/>
        <link href="bootstrap/css/font-awesome.min.css" rel="stylesheet" type="text/css"/>
        <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'>
        <link href="bootstrap/style.css" rel="stylesheet" type="text/css"/>
        <script>
            function Delete(){
                    return confirm("Do you want to Delete this User?");
            }
        </script>
        
    </head>
    <body style="background-image: url(images/pat.png);">
        <div class="container ">
            <div class="row" >
                <div class="col-md-8">
                    <nav class="navbar navbar-default navbar-fixed-top"  id="navuu" >
                        <div class="container">
                            <div class="navbar-header col-md-5">
                                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                                    <span class="sr-only">Toggle navigation</span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                </button>
                             <img src="images/log1.png" id="img-logo" class="img-responsive col-md-12 col-sm-3 col-xs-6 col-xs-6" />
                        </div>
                            
                            <div class="collapse navbar-collapse navbar-ex1-collapse col-md-7">
                                <ul class="nav navbar-nav" style="font-family: Times New Roman; ">
                                    <li><a href="#" >Home</a>
                                    </li>
                                    <li><a href="#">About</a>
                                    </li>
                                    <li><a href="#">Contact</a>
                                    </li>
                                    <li><a href="logout.php" >Logout</a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </nav>
                </div>
            </div>
        </div>
        
        <div class="container ">
            <div class="row top-margin-low">
                <div class="col-md-3 top-margin" >
                    <div class="panel " style="min-height: 485px">
                        <div class="panel-heading" style="font-size: 20px; background: #D8D8BF;color: #236B8E">
                            <b> Information</b>
                        </div>
                        <div class="panel-body">
                            <?php include 'menuList.php';?>

                        </div>

                    </div>
                </div>
                
                <div class="col-md-9 top-margin">
                    <div class="panel" style="min-height: 485px">
                        <div class="panel-heading " style="font-size: 20px; background: #D8D8BF;color: #236B8E">
                            <strong>Welcome To Taxi Transport System</strong>
                        </div>
                        <div class="panel-body ">
                            <div class="row" style="margin-bottom: 83px;">
                                <div class="contents col-md-12">
                                    <div class="col-md-12">
                                        <div class="col-md-12 page-title " style="background: #004A4A; margin-bottom: 20px; min-height: 40px;color: white; padding-top: 10px"><b>View Driver</b></div>
                                       <div class="clearfix"></div>
                                       <div class="table-responsive">
                                            
                                           <div class="table-responsive">
                                            <div class="col-md-12 col-sm-6 col-xs-6" class="container-fluid" style=" margin-top:">
                                                <a href="driverForm.php"> <button type="button" class="btn btn-success pull-right" name="diver">Add Driver</button></a>
                                                <div class="row">
                                                    <div class="col-md-2">
                                                        <a href="viewCar.php">View Car</a>
                                                    </div>
                                                    <div class="col-md-2">
                                                        <a href="viewStation.php">View Station</a>
                                                    </div>
                                                    <div class="col-md-8"></div>
                                                </div>
                                               <div class="table-responsive">
                                                  <table class="table table-striped table-condensed display" id="example" style="width:100%; margin-top: 10px">
                                                    <thead>
                                                            <tr>
                                                                    <th>Driver ID</th>
                                                                    <th>User Name</th>
                                                                    <th>Plate No</th>
                                                                    <th>Car Model</th>
                                                                    <th>Car License</th>
                                                                    <th>Car Color</th>
                                                                    <th>Tin No</th>
                                                            </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php
                                                            $q=$con->query("select * from driver,car where driver.driverID=car.driverID")or die("$con->error");
                                                            $i=1;
                                                            while($fetch=$q->fetch_array()){
                                                                    ?>
                                                                    <tr>
                                                                            <td><?php echo $i ?></td>
                                                                            <td><?php echo $fetch["userName"] ?></td>
                                                                            <td><?php echo $fetch["plateNo"] ?></td>
                                                                            <td><?php echo $fetch["carModel"] ?></td>
                                                                            <td><?php echo $fetch["carLicense"] ?></td>
                                                                            <td><?php echo $fetch["carColor"] ?></td>
                                                                            <td><?php echo $fetch["tinNo"] ?></td>
                                                                            

                                                                    </tr>
                                                                    <?php
                                                                     $i++;
                    
                                                            }
                                                    ?>
                                        </tbody>
                                            </table>
                                       </div>
                                        </div>

                                           
                                       </div>
                                    </div>
                                </div>
                            </div>
                        <!--<h6 class="page-head-lines"></h6>-->
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-12 top-margin footer-section">
            &copy; 2018 | &nbsp; All Rights Reserved | Thabit & Abdallah
        </div>
        
        
        
        <script src="bootstrap/js/jquery-1.10.2.js" type="text/javascript"></script>
        <script src="bootstrap/js/bootstrap.js" type="text/javascript"></script>
    </body>
</html>

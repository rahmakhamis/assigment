<?php
session_start();
include ("connection.php");
if(isset($_POST["btn_S"])){
        $user=$_POST["useName"];
        $pass=$_POST["pass"];
        $role=$_POST["role"];
    
    
        $FirstN=$_POST["FirstName"];
        $LastN=$_POST["LastName"];
        $adres=$_POST["addres"];
        $phon=$_POST["phone"];
        $email=$_POST["email"];
        $nation=$_POST["nation"];
        
        $pNo=$_POST["Plateno"];
        $liceC=$_POST["licenc"];
        $model=$_POST["Carmodel"];
        
         $carL=$_POST["Carlicense"];
        $carC=$_POST["CarColor"];
        $tinNo=$_POST["tinNumber"];
        
        $station=$_POST["Stationname"];
        $street=$_POST["Street"];

        $check=$con->query("SELECT * from logins WHERE userName ='$user'") or die("$con->error");		 
       $rows=mysqli_num_rows($check);
       if($rows==1){
           $_SESSION["fail"]="The user name already exist";
		header("location:driverForm.php");
           
       }else{
           
                       $logintr=$con->query("INSERT INTO logins VALUES('$user','$pass','$role','$FirstN','$LastN','$adres','$phon','$email','$nation')");
                       
                       $driverr=$con->query("INSERT INTO driver(driverID,LicenseClass,userName,status) VALUES(NULL,'$liceC','$user',0)")or die("$con->error");
                       
                       $quer=$con->query("select * from driver order by driverID desc limit 1 ")or die("$con->error");
                       while($row=mysqli_fetch_array($quer)){
                               $driverID=$row['driverID'];
                       }
                       $driver1=$con->query("INSERT INTO car VALUES('$pNo','$model','$carL','$carC','$tinNo','$driverID')")or die("$con->error");
                        $quer2=$con->query("select * from car order by plateNo desc limit 1 ")or die("$con->error");
                       while($row=mysqli_fetch_array($quer2)){
                               $pID=$row['plateNo'];
                       }
                       $driver2=$con->query("INSERT INTO station VALUES(NULL,'$pID','$station','$street')")or die("$con->error");
                       header("location:viewdriver.php");
               
       }
}
?>
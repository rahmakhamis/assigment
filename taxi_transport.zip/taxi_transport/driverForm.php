<?php
include ("connection.php");
session_start();
if(!isset($_SESSION['users'])){
	header("location:index.php");
}
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>TAXI DRIVER</title>
        
        <link href="bootstrap/css/bootstrap.css" rel="stylesheet" type="text/css"/>
        <link href="bootstrap/css/font-awesome.min.css" rel="stylesheet" type="text/css"/>
        <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'>
        <link href="bootstrap/style.css" rel="stylesheet" type="text/css"/>
		
        
    </head>
    <body style="background-image: url(images/pat.png);">
        <div class="container ">
            <div class="row" >
                <div class="col-md-8">
                    <nav class="navbar navbar-default navbar-fixed-top"  id="navuu" >
                        <div class="container">
                            <div class="navbar-header col-md-5">
                                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                                    <span class="sr-only">Toggle navigation</span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                </button>
                             <img src="images/log1.png" id="img-logo" class="img-responsive col-md-12 col-sm-3 col-xs-6 col-xs-6" />
                        </div>
                            
                            <div class="collapse navbar-collapse navbar-ex1-collapse col-md-7">
                                <ul class="nav navbar-nav" style="font-family: Times New Roman; ">
                                    <li><a href="#" >Home</a>
                                    </li>
                                    <li><a href="#">About</a>
                                    </li>
                                    <li><a href="#">Contact</a>
                                    </li>
                                    <li><a href="logout.php" >Logout</a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </nav>
                </div>
            </div>
        </div>
        
        <div class="container ">
            <div class="row top-margin-low">
                <div class="col-md-3 top-margin" >
                    <div class="panel " style="min-height: 655px">
                        <div class="panel-heading" style="font-size: 20px; background: #D8D8BF;color: #236B8E">
                            <b> Information</b>
                        </div>
                        <div class="panel-body">
                            <?php include 'menuList.php';?>

                        </div>

                    </div>
                </div>
                
                <div class="col-md-9 top-margin">
                    <div class="panel" style="min-height: 485px">
                        <div class="panel-heading " style="font-size: 20px; background: #D8D8BF;color: #236B8E">
                            <strong>Welcome To Taxi Transport System</strong>
                        </div>
                        <div class="panel-body ">
                            <div class="row" style="margin-bottom: 83px;">
                                <div class="contents col-md-12">
                                    <div class="col-md-12">
                                        <div class="col-md-12 page-title " style="background: #004A4A; margin-bottom: 20px; min-height: 40px;color: white; padding-top: 10px"><b>Driver Form</b></div>
                                       <div class="clearfix"></div>
                                       <div class="table-responsive">
                                            
                                           
                                                        <form action="driverHendler.php" method="post">

                                                                <div class="row">
                                                                    <div class="col-md-4">
                                                                            <label>User Name</label>
                                                                            <input type="text" name="useName" required="required" class="form-control text">
                                                                    </div>
                                                                    <div class="col-md-4">
                                                                            <label>Password</label>
                                                                            <input type="password" name="pass" required="required" class="form-control text">
                                                                    </div>
                                                                    <div class="col-md-4">
                                                                        <label>Role</label>
                                                                        <select name="role" required="required" class="form-control text">
                                                                                <option value="">Select Role</option>
                                                                                <option value="Driver">Driver</option>
                                                                        </select>
                                                                    </div>
                                                                </div>	
                                                                <div class="row">
                                                                    <div class="col-md-4">
                                                                            <label>First Name</label>
                                                                            <input type="text" name="FirstName" required="required" class="form-control text">
                                                                    </div>
                                                                    <div class="col-md-4">
                                                                            <label>Last Name</label>
                                                                            <input type="text" name="LastName" required="required" class="form-control text">
                                                                    </div>
                                                                    <div class="col-md-4">
                                                                                <label>Address</label>
                                                                                <input type="text" name="addres" required="required" class="form-control text">
                                                                    </div>
                                                                </div>	
                                                            <div class="row">
                                                                    <div class="col-md-4">
                                                                            <label>Phone No</label>
                                                                            <input type="text" name="phone"  required="required" class="form-control text">
                                                                    </div>
                                                                    <div class="col-md-4">
                                                                            <label>Email</label>
                                                                            <input type="email" name="email" required="required" class="form-control text">
                                                                    </div>
                                                                    <div class="col-md-4">
                                                                                <label>Nationality</label>
                                                                                <select name="nation" class="form-control text" required="required">
                                                                                    <option value="">Select Nation</option>
                                                                                            <option value="Tanzanian">Tanzanian</option>
                                                                                            <option value="Kenyan">Kenyan</option>
                                                                                            <option value="Uganda">Uganda</option>
                                                                                            <option value="Malawi">Malawi</option>
                                                                                            <option value="Burundi">Burundi</option>
                                                                                            <option value="South Afrika">South Afrika</option>
                                                                                            <option value="Uganda">Indonesia</option>
                                                                                            <option value="Uganda">Bangladesh</option>
                                                                                            <option value="Uganda">Pakistan</option>
                                                                                            <option value="Uganda">India</option>
                                                                                            <option value="Uganda">London</option>
                                                                                    </select>
                                                                    </div>
                                                                </div>






                                                                        <div class="row">
                                                                                <div class="col-md-4">
                                                                                <label>License Class</label>
                                                                                        <select name="licenc" class="form-control text">
                                                                                        <option value="">Select Class</option>
                                                                                                <option value="A">A</option>
                                                                                                <option value="B">B</option>
                                                                                                <option value="B1">B1</option>
                                                                                                <option value="B2">B2</option>
                                                                                                <option value="C">C</option>
                                                                                                <option value="C1">C1</option>
                                                                                                <option value="C2">C2</option>
                                                                                                <option value="C3">C3</option>
                                                                                                <option value="D">D</option>
                                                                                                <option value="D1">D1</option>
                                                                                                <option value="E">E</option>
                                                                                        </select><br>
                                                                                </div>
                                                                            <div class="col-md-4">
                                                                                    <label>Plate Number</label>
                                                                                    <input type="text" name="Plateno" class="form-control text" required/>
                                                                            </div>
                                                                            <div class="col-md-4">
                                                                                    <label>Car Model</label>
                                                                                    <input type="text" name="Carmodel" required="required" class="form-control text">
                                                                            </div>
                                                                        </div>	






                                                                <div class="row">
                                                                        <div class="col-md-4">
                                                                                    <label>Car License</label>
                                                                                    <input type="text" required="required" name="Carlicense" class="form-control text">
                                                                            </div>
                                                                        <div class="col-md-4">
                                                                                <label>Car Color</label>
                                                                                <input type="text" name="CarColor" required="required" class="form-control text">
                                                                        </div>
                                                                    <div class="col-md-4">
                                                                            <label>Tin Number</label>
                                                                            <input type="number" name="tinNumber" required="required" class="form-control text">
                                                                    </div>
                                                                </div>	
                                                            
                                                            <div class="row">
                                                                        <div class="col-md-6">
                                                                                    <label>Station Name</label>
                                                                                    <input type="text" name="Stationname" required="required" class="form-control text">
                                                                            </div>
                                                                        <div class="col-md-6">
                                                                                <label>Station Street</label>
                                                                                    <input type="text" name="Street" required="required" class="form-control text">
                                                                        </div>
                                                                    
                                                                </div>	





                                                                <div class="form-group" style='margin-top:10px'>
                                                                        <input type="submit" name="btn_S" class="btn btn-primary" value="submit">
                                                                </div>
                                                        </form>

                                           
                                       </div>
                                    </div>
                                </div>
                            </div>
                        <!--<h6 class="page-head-lines"></h6>-->
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-12 top-margin footer-section">
            &copy; 2018 | &nbsp; All Rights Reserved | Thabit & Abdallah
        </div>
        
        
        
        <script src="bootstrap/js/jquery-1.10.2.js" type="text/javascript"></script>
        <script src="bootstrap/js/bootstrap.js" type="text/javascript"></script>
    </body>
</html>

<?php
    session_start();
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <title>TAXI DRIVER I</title>
	
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
    <link href="font-awesome/css/font-awesome.css" rel="stylesheet" type="text/css"/>
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
    <link href="bootstrap/style.css" rel="stylesheet" type="text/css"/>
    
    <script type="text/javascript">
        history.pushState(null, null, '');
        window.addEventListener('popstate', function(event){
        history.pushState(null, null, '');
        });
    </script>
</head>
<body style="background-image: url(images/pat.png);">
    <div class="container">
        <div class="row text-center " style="padding-top:65px;" >
            <div class="col-md-6 col-md-offset-3 col-sm-6 col-sm-offset-3 col-xs-10 col-xs-offset-1">
                <img src="images/logoTa.png" id="logo1" alt="" class="img-responsive"/>
                <div class="sub-logo-title" style="margin-top:10px;"></div>
            </div>
        </div>
         <div class="row ">
               
             <div class="col-md-4 col-md-offset-4 col-sm-6 col-sm-offset-3 col-xs-10 col-xs-offset-1" style="background: #D8D8BF; border-radius:20px">
                           
                <div class="panel-body">
                    <form role="form" action="newhandler.php" method="post">
                        <?php
                            if (isset($_SESSION['invalid']))
                         {?>
                             <p style="color:red;text-align:center;"> <?php echo $_SESSION['invalid'];?> </p> 
                         <?php  
                         } ?>
                        <hr />
                        <h4><center>Enter Details to Login</center></h4>
                           <br />
                         <div class="form-group input-group">
                            <span class="input-group-addon"><i class="fa fa-home"  ></i></span>
                            <input type="text" class="form-control" name="user" placeholder="Your Username " required="required"/>
                        </div>
                           
                        <div class="form-group input-group">
                            <span class="input-group-addon"><i class="fa fa-lock"  ></i></span>
                            <input type="password" class="form-control" name="pass" placeholder="Your Password" required="required" />
                        </div>

                           <input type="submit" name="log_btn" class="btn btn-primary " value="Login Now">
                        <hr />
                        Not register ? <a href="customerReg.php" >click here to register</a> 
                    </form>
                </div>

            </div>              
        </div>
    </div>

    <?php 
        unset($_SESSION['invalid']);
    ?>
</body>
</html>
